package org.westada.quicklauncher;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button secondActivity = (Button) findViewById(R.id.secondActivity);
        secondActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), secondActivity.class);
                startIntent.putExtra("org.westada.quicklauncher.Something", "Voosh! You have teleported to another app");
                startActivity(startIntent);
            }
        });

        Button googleBtn = (Button)findViewById(R.id.firstActivity);
        googleBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String google = "http://www.westada.org";
                Uri webaddress = Uri.parse(google);

                Intent gotoGoogle = new Intent(Intent.ACTION_VIEW, webaddress);
                if (gotoGoogle.resolveActivity(getPackageManager()) != null){
                    startActivity(gotoGoogle);
                }
            }
        });


        Button project1Btn = (Button)findViewById(R.id.project1);
        project1Btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage("org.westada.shouldwork");
                    if (launchIntent != null) {
                    startActivity(launchIntent);
                    }
                }
            });

        Button project2Btn = (Button)findViewById(R.id.project2);
        project2Btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage("org.westada.slopecalc");
                if (launchIntent != null) {
                    startActivity(launchIntent);
                }
            }
        });

        }






    }

