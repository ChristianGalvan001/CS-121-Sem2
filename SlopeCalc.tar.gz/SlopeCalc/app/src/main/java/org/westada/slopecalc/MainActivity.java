package org.westada.slopecalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button calcBtn = (Button) findViewById(R.id.calcBtn);
        calcBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText y1 = (EditText) findViewById(R.id.Y1);
                EditText y2 = (EditText) findViewById(R.id.Y2);
                EditText x1 = (EditText) findViewById(R.id.x1);
                EditText x2 = (EditText) findViewById(R.id.x2);
                TextView mResult = (TextView) findViewById(R.id.mResult);
                TextView bResult = (TextView) findViewById(R.id.bResult);
                TextView equationLabel = (TextView) findViewById(R.id.equationLabel);
                Double rise;
                Double run;
                Double getx1,gety1;
                double slope;
                double yIntercept;

            rise = dontRepeatSelf(y2)- dontRepeatSelf(y1);
            run = dontRepeatSelf(x2)- dontRepeatSelf(x1);
            getx1 = dontRepeatSelf(x1);
            gety1 = dontRepeatSelf(y1);
            slope = (rise / run);
            yIntercept = (gety1 -(slope * getx1));

                mResult.setText(slope + "");
                bResult.setText( yIntercept + "");
                equationLabel.setText("Y = " + slope + "X" + " + " + yIntercept);

            }
        });
    }





    public double dontRepeatSelf(EditText num ) {
        return Double.parseDouble(num.getText().toString());

    }

}
