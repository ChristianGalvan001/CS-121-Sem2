package org.westada.mysqlsample;

public class DbStrings {

    static final String DATABASE_URL = "192.168.1.118:3306";
    static final String DATABASE_NAME = "fruit";
    static final String USERNAME = "root";
    static final String PASSWORD = "toor";

}
