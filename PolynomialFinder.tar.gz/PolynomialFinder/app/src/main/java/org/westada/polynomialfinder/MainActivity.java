package org.westada.polynomialfinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calculatebtn = (Button) findViewById(R.id.calculatebtn);
        calculatebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText y1 = (EditText) findViewById(R.id.Y1);
                EditText y2 = (EditText) findViewById(R.id.Y2);
                EditText y3 = (EditText) findViewById(R.id.Y3);
                EditText x1 = (EditText) findViewById(R.id.X1);
                EditText x2 = (EditText) findViewById(R.id.X2);
                EditText x3 = (EditText) findViewById(R.id.X3);
                TextView Result = (TextView) findViewById(R.id.equationText);
                Double getx1,getx2,getx3,gety2,gety3,gety1;
                double slope;
                double yIntercept;


                double a = ( (get(x1) * (get(y3) - get(y2)) + get(x2) * (get(y1) - get(y3)) + get(x3) * (get(y2) - get(y1))) / ( (get(x1) - get(x2)) * (get(x1) - get(x3)) * (get(x2) - get(x3)) ));
                double b =  ((get(y2) - get(y1)) / (get(x2) - get(x1))) - (a * (get(x1) + get(x2)));
                double c = (get(y1) - (a * get(x1)) - (b * get(x1)));
                Result.setText( "f(x) = " + a + "x^2 + " +b + "X + " + c);

            }
        });





    }

    public double get(EditText num ) {
        return Double.parseDouble(num.getText().toString());

    }




}
