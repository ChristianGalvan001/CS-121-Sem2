package org.westada.shouldwork;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addBtn = (Button) findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                doTheMath("+");

            }
        });
//End of Add

        Button subBtn = (Button) findViewById(R.id.subBtn);
        subBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                doTheMath("-");


            }
        });
//End of Subtract

        Button mulBtn = (Button) findViewById(R.id.mulBtn);
        mulBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                doTheMath("*");



            }
        });
//End of Multiply

        Button divBtn = (Button) findViewById(R.id.divBtn);
        divBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                doTheMath("/");

            }
        });
//End of Divide


        Button ExpBtn = (Button) findViewById(R.id.ExpBtn);
        ExpBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                doTheMath("^");

            }
        });
//End of Exponent

        Button sqRootBtn = (Button) findViewById(R.id.sqRootBtn);
        sqRootBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                doTheMath("sqRoot");

            }
        });
//End of Square Root



    }

    public double dontRepeatSelf(EditText num ) {
        return Double.parseDouble(num.getText().toString());

    }

    public int doTheMath(String sign){
        EditText firstNumEditText = (EditText) findViewById(R.id.firstNumEditText);
        EditText secondNumEditText = (EditText) findViewById(R.id.secondNumEditText);
        TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

        if (sign.equals("/")){
            double result = (dontRepeatSelf(firstNumEditText) / dontRepeatSelf(secondNumEditText));
            resultTextView.setText( result + "");
        }
        if (sign.equals("*")){
            double result = (dontRepeatSelf(firstNumEditText) * dontRepeatSelf(secondNumEditText));
            resultTextView.setText( result + "");
        }
        if (sign.equals("+")){
            double result = (dontRepeatSelf(firstNumEditText) + dontRepeatSelf(secondNumEditText));
            resultTextView.setText( result + "");
        }
        if (sign.equals("-")){
            double result = (dontRepeatSelf(firstNumEditText) - dontRepeatSelf(secondNumEditText));
            resultTextView.setText( result + "");
        }
        if (sign.equals("^")){
            double result = Math.pow(dontRepeatSelf(firstNumEditText), dontRepeatSelf(secondNumEditText));
            resultTextView.setText( result + "");
        }
        if (sign.equals("sqRoot")){
            double result = Math.sqrt(dontRepeatSelf(firstNumEditText) );
            resultTextView.setText( result + "");
        }
        else{
            double result = 0;
        }

        return(0);
    }




} // End of public class
